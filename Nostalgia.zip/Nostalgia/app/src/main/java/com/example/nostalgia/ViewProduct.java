package com.example.nostalgia;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.nostalgia.Models.Products;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class ViewProduct extends AppCompatActivity {
    TextView desc, name, price, category, quantity;
    ImageView image;
    Button addToCart;
    String ownerID;
    String id = "";
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    FirebaseAuth auth;
    Toolbar toolbar;
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product);



            id = getIntent().getStringExtra("pid");
            desc = (TextView) findViewById(R.id.text);
            name = (TextView) findViewById(R.id.mainTitle);
            price = (TextView) findViewById(R.id.price);
            category = (TextView) findViewById(R.id.category);
            quantity = (TextView) findViewById(R.id.quantity);
            image = (ImageView) findViewById(R.id.mainIcon);
            addToCart = (Button) findViewById(R.id.addToCart);
            back = (ImageView) findViewById(R.id.back);
            getProdctDetails(id);
            auth = FirebaseAuth.getInstance();
            firebaseUser = auth.getCurrentUser();
            assert firebaseUser != null;
//            String userid = firebaseUser.getUid();
           // reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
            //getting the toolbar
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

            //setting the title
            toolbar.setTitle(name.getText().toString());

            //placing toolbar in place of actionbar
            setSupportActionBar(toolbar);

            addToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addingToCartList();
                }
            });
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent in = new Intent(ViewProduct.this, Products_Page.class);
                    startActivity(in);



                }
            });


    }

    private void addingToCartList() {
        try {

            final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            String saveCurrentDate, saveCurrentTime;
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat currentDate = new SimpleDateFormat("MMM dd, yyyy");
            saveCurrentDate = currentDate.format(calendar.getTime());

            SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss a");
            saveCurrentTime = currentTime.format(calendar.getTime());
            String userid = firebaseUser.getUid();

            final DatabaseReference databaseref = FirebaseDatabase.getInstance().getReference().child("Cart List");
            if (!firebaseUser.getUid().equals(ownerID)) {
                HashMap<String, Object> CartMap = new HashMap<>();
                CartMap.put("pid", id);
                CartMap.put("date", saveCurrentDate);
                CartMap.put("time", saveCurrentTime);
                CartMap.put("category", category.getText().toString());
                CartMap.put("pName", name.getText().toString());
                CartMap.put("pDescription", desc.getText().toString());
                CartMap.put("pPrice", price.getText().toString());

                CartMap.put("pQuantity", quantity.getText().toString());
                databaseref.child("User View").child(userid)
                        .child("Products").child(id)
                        .updateChildren(CartMap)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if (task.isSuccessful()) {
                                    Toast.makeText(ViewProduct.this, "added to cart successfully", Toast.LENGTH_LONG).show();
                              /*  Intent in = new Intent(ViewProduct.this, Products_Page.class);
                                startActivity(in);*/
                                }
                            }
                        });
            }
              else
            {   Toast.makeText(this,"you can't add your products to your cart",Toast.LENGTH_LONG).show();}

        }
        catch (Exception ex)
        {
            Toast.makeText(this,"you are not a user!",Toast.LENGTH_LONG).show();
            Intent in = new Intent(ViewProduct.this, Home.class);
            startActivity(in);


       }
    }
    private void getProdctDetails(String id) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Products").child("View Of Products");
        ref.child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    Products model = dataSnapshot.getValue(Products.class);
ownerID=model.getOwnerID();
                        name.setText(model.getPname());
                        desc.setText("Description: " +model.getPdescription());
                        Picasso.get().load(model.getImage()).into(image);
                        price.setText("Price = " + model.getPprice() + "$");
                        category.setText("Category: " + model.getCategory());
                        quantity.setText("Quantity: " + model.getpQuantity());
                    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                    toolbar.setTitle(name.getText().toString());

                    //placing toolbar in place of actionbar
                    setSupportActionBar(toolbar);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.addCategory:
                Intent in1 = new Intent(ViewProduct.this, addNewCategory.class);
                startActivity(in1);
                break;


            case R.id.menuLogout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(ViewProduct.this, LoginActivity.class));
                finish();
                break;
            case R.id.cart:
                Intent in = new Intent(ViewProduct.this, cartList.class);
                startActivity(in);
                break;
            case R.id.giveReport:
                Intent in2 = new Intent(ViewProduct.this, giveReport.class);
                startActivity(in2);
                break;

            case R.id.suggestCategory:
                Intent in3 = new Intent(ViewProduct.this, suggestNewCategory.class);
                startActivity(in3);
                break;

            case R.id.yourProducts:
                Intent in4 = new Intent(ViewProduct.this, yourProducts.class);
                startActivity(in4);
                break;

        }
        return true;
    }
}
