package com.example.nostalgia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Entry extends AppCompatActivity {

    FirebaseUser firebaseUser;

    @Override
    protected void onStart() {
        super.onStart();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        //check if the user is already logged in

        if(firebaseUser!=null)
        {
            Intent intent =new  Intent(Entry.this, Home.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);


    }

    public void login(View view) {
        Intent intent = new Intent(Entry.this, LoginActivity.class);
        startActivity(intent);
    }



    public void enterAsGuest(View view) {
        Intent intent = new Intent(Entry.this, Home.class);/////change
        startActivity(intent);
    }
}
