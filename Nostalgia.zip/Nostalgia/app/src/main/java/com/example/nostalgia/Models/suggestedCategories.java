package com.example.nostalgia.Models;


public class suggestedCategories
{




    private String Name;




    public suggestedCategories()
    {

    }

    public suggestedCategories(String Name) {
        this.Name =Name;


    }


    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
}