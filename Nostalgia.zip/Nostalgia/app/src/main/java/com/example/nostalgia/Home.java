package com.example.nostalgia;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.nostalgia.Models.Categories;
import com.example.nostalgia.ViewHolder.categoryViewHolder;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;


public class Home extends AppCompatActivity {
    ImageView p, j, b, c, k, f;
    ListView list;

    FirebaseAuth auth;
    String[] title;
    String[] desc;
    int[] icon;
    FirebaseUser firebaseUser;
    ImageView back;

    private DatabaseReference CategoriesRef;
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    String input = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
//getting the toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        //setting the title
        toolbar.setTitle("Home");
        back= (ImageView) findViewById(R.id.back);
        //placing toolbar in place of actionbar
        setSupportActionBar(toolbar);
        recyclerView = findViewById(R.id.recycler_menu);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);



        onStart();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.addCategory:
                Intent in1 = new Intent(Home.this, addNewCategory.class);
                startActivity(in1);
                break;
            case R.id.addProduct:
                Intent in11 = new Intent(Home.this, selectCategory.class);
                startActivity(in11);
                break;


            case R.id.menuLogout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(Home.this, LoginActivity.class));
                finish();
                break;
            case R.id.cart:
                Intent in = new Intent(Home.this, cartList.class);
                startActivity(in);
                break;

            case R.id.yourProducts:
                Intent in3 = new Intent(Home.this, yourProducts.class);
                startActivity(in3);
                break;

            case R.id.giveReport:
                Intent in2 = new Intent(Home.this, giveReport.class);
                startActivity(in2);
                break;

            case R.id.suggestCategory:
                Intent in4 = new Intent(Home.this, suggestNewCategory.class);
                startActivity(in4);
                break;

            case R.id.viewReports:
                Intent in5 = new Intent(Home.this, ReportsList.class);
                startActivity(in5);
                break;

            case R.id.viewSuggestedCategory:
                Intent in6 = new Intent(Home.this, viewSuggestCategories.class);
                startActivity(in6);
                break;

        }
        return true;
    }


    @Override
    protected void onStart() {
        super.onStart();

        auth = FirebaseAuth.getInstance();
        firebaseUser = auth.getCurrentUser();

        CategoriesRef = FirebaseDatabase.getInstance().getReference().child("Categories").child("DzpHl905hbeoth7spY7ray1pOy53");
        FirebaseRecyclerOptions<Categories> options;

        options =
                new FirebaseRecyclerOptions.Builder<Categories>()
                        .setQuery(CategoriesRef, Categories.class)
                        .build();


        FirebaseRecyclerAdapter<Categories, categoryViewHolder> adapter =
                new FirebaseRecyclerAdapter<Categories, categoryViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull categoryViewHolder holder, int position, @NonNull final Categories model) {

                        holder.txtCategoryName.setText("  " + model.getName());
                        //   holder.txtProductDescription.setText(model.getDescription());
                        Picasso.get().load(model.getImage()).into(holder.imageView);
                        if (firebaseUser.getUid().equals("DzpHl905hbeoth7spY7ray1pOy53")) {
                            holder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    CharSequence options[] = new CharSequence[]
                                            {
                                                    "View",
                                                    "Remove"
                                            };
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                                    builder.setTitle("Options:");
                                    builder.setItems(options, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (which == 0) {
                                                Intent in = new Intent(Home.this, Products_Page.class);
                                                in.putExtra("Category", model.getName());
                                                startActivity(in);
                                            } else if (which == 1) {
                                                String userid = firebaseUser.getUid();
                                                CategoriesRef.child(model.getCid()).removeValue()
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(Home.this, "Item removed successfully", Toast.LENGTH_LONG).show();
                                                                }
                                                            }
                                                        });
                                            }
                                        }

                                    });
                                    builder.show();

                                }
                            });

                        } else {
                            holder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(Home.this, Products_Page.class);
                                    in.putExtra("Category", model.getName());
                                    startActivity(in);


                                }
                            });
                        }
                    }
                    @NonNull
                    @Override
                    public categoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw, parent, false);
                        categoryViewHolder holder = new categoryViewHolder(view);
                        return holder;
                    }
                };
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }
}




