package com.example.nostalgia.Interface;

import android.view.View;


public interface itemClickListener
{
    void onClick(View view, int position, boolean isLongClick);
}
